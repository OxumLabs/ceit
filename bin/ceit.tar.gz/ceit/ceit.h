#ifndef CEIT_H
#define CEIT_H

#include <stddef.h>

typedef struct Memory Memory;
typedef struct Memchunk Memchunk;

/**
 * @brief Structure representing a block of memory allocated from a Page.
 * Contains metadata for block management.
 */
struct Memory {
    char name[32];          ///< Name of the memory block for easy reference.
    size_t size;            ///< Size of the allocated block.
    int is_free;            ///< Indicates if the block is free (1) or allocated (0).
    Memory* next;           ///< Pointer to the next memory block in the list.
    char data[50];            ///< Flexible array member for block data.
};

/**
 * @brief Structure representing a large memory allocation area (Page) from which
 * smaller blocks (Memory) are allocated.
 */
struct Memchunk {
    char name[32];          ///< Name of the page for reference.
    size_t total_size;      ///< Total size of the Page's memory.
    Memory* memory_pool;    ///< Head pointer to linked list of Memory blocks.

    size_t used_memory;     ///< Used memory in bytes.
    size_t free_memory;     ///< Free memory in bytes.
    Memchunk* next;             ///< Pointer to the next page (if chaining pages).
};


/**
 * @brief Initializes a new memory Memchunk with the given name and total size.
 * 
 * This function allocates memory for the Memchunk structure and initializes
 * the memory pool. Initially, all memory in the Memchunk is free.
 * 
 * @param name The name of the Memchunk to initialize.
 * @param total_size The total size of the memory Memchunk.
 * 
 * @return A pointer to the initialized Memchunk structure, or NULL if memory 
 *         allocation fails.
 * 
 * Example usage:
 * ```
 * Memchunk* chunk = memc_init("Chunk1", 1024);
 * if (chunk) {
 *     // Use the chunk
 * }
 * ```
 */
Memchunk* memc_init(const char* name, size_t total_size);

/**
 * @brief Allocates memory from the Memchunk's memory pool.
 * 
 * This function searches for the best-fit memory block in the pool that is large
 * enough to satisfy the request and allocates it. If the block is larger than 
 * necessary, it is split. The allocated memory block is marked as used, and 
 * the Memchunk's used/free memory statistics are updated.
 * 
 * @param Memchunk The Memchunk from which memory is allocated.
 * @param size The size of the memory block to allocate.
 * @param block_name The name of the allocated memory block.
 * 
 * @return A pointer to the allocated memory block, or NULL if allocation fails.
 * 
 * Example usage:
 * ```
 * void* allocated_memory = memory_alloc(chunk, 256, "Block1");
 * if (allocated_memory) {
 *     // Use the allocated memory
 * }
 * ```
 */
void* memory_alloc(Memchunk* page, size_t size, const char* block_name);

/**
 * @brief Writes data to the allocated memory block.
 * 
 * This function writes data to the memory block. If the `size` is 0, it will 
 * automatically calculate the size based on the type of data. For example, 
 * if the data is a string, it will calculate the length of the string.
 * 
 * @param mem_block The memory block to write data to.
 * @param data The data to write.
 * @param size The size of the data. If size is 0, it will auto-calculate based 
 *             on data type (for example, string length).
 * 
 * @return 0 on success, -1 on failure.
 * 
 * Example usage:
 * ```
 * char* my_data = "Hello, World!";
 * if (memory_write(mem_block, my_data, 0) == 0) {
 *     // Successfully written data to memory block
 * }
 * ```
 */
int memory_write(void* mem_block, const void* data, size_t size);

/**
 * @brief Reads data from the allocated memory block into the provided buffer.
 * 
 * This function reads the specified amount of data from the memory block and 
 * stores it in the provided buffer.
 * 
 * @param mem_block The memory block to read data from.
 * @param buffer The buffer to store the data.
 * @param size The size of the data to read.
 * 
 * @return 0 on success, -1 on failure.
 * 
 * Example usage:
 * ```
 * char buffer[256];
 * if (memory_read(mem_block, buffer, sizeof(buffer)) == 0) {
 *     // Successfully read data into buffer
 * }
 * ```
 */
int memory_read(const void* mem_block, void* buffer, size_t size);

/**
 * @brief Frees the memory block with the given name.
 * 
 * This function frees the memory block with the specified name and updates 
 * the Memchunk's used and free memory statistics. If adjacent free memory 
 * blocks exist, they will be coalesced to form a larger free block.
 * 
 * @param Memchunk The Memchunk to free the memory from.
 * @param block_name The name of the memory block to free.
 * 
 * Example usage:
 * ```
 * memory_free(chunk, "Block1");  // Frees the memory block named "Block1"
 * ```
 */
void memory_free(Memchunk* page, const char* block_name);
/**
 * @brief Deallocates the memory Memchunk.
 * 
 * WARNING: Before calling this function, ensure that all memory blocks allocated
 * from the Memchunk have been freed, otherwise the program may crash due to invalid
 * memory access or memory leaks.
 * 
 * @param Memchunk The Memchunk to deallocate.
 * 
 * Example usage:
 * ```
 * memc_dealloc(chunk);  // Deallocate the Memchunk
 * ```
 */
void memc_dealloc(Memchunk* page);

/**
 * @brief Debug function to display the status of multiple Memchunks.
 * 
 * This function prints details of each Memchunk, including its total size, used 
 * memory, free memory, and the memory blocks inside it.
 * 
 * @param num_Memchunks The number of Memchunks to display.
 * 
 * Example usage:
 * ```
 * memc_dbg(2, chunk1, chunk2);  // Display status of chunk1 and chunk2
 * ```
 */
void memc_dbg(int num_pages, ...);

/**
 * @brief Debug function to display details of memory blocks.
 * 
 * This function prints details of the specified memory blocks.
 * 
 * @param num_mem The number of memory blocks to display.
 * 
 * Example usage:
 * ```
 * mem_dbg(1, block1);  // Display status of block1
 * ```
 */
void mem_dbg(int num_mem, ...);
#endif // CEIT_H
